package com.kh.gongiapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GongiappApplicationTests {

	@Test
	void contextLoads() {
	}

}
