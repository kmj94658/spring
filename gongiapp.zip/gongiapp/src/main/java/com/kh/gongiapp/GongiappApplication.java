package com.kh.gongiapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GongiappApplication {

	public static void main(String[] args) {
		SpringApplication.run(GongiappApplication.class, args);
	}

}
